### Hexlet tests and linter status:
[![Actions Status](https://github.com/veterinastya/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/veterinastya/python-project-49/actions)

#аскинема, демонстрирующая установку пакета, запуск игры brain-even и варианты поражения и победы в игре.
https://asciinema.org/a/MkAELP3e5mxrMR1nIMRfP6CCN
