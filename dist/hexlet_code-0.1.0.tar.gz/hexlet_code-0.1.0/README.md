### Hexlet tests and linter status:
[![Actions Status](https://github.com/veterinastya/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/veterinastya/python-project-49/actions)

To start the Brain-games you have to do following:
1. Clone my repository:
git clone https://github.com/veterinastya/Brain-Games.git

2. Update your pip:
python -m pip install --upgrade pip

3. Install poetry


#asciinema demonstrating package installation, 'brain-even' game start and possible options of defeat and victory in the game.
https://asciinema.org/a/MkAELP3e5mxrMR1nIMRfP6CCN

#asciinema demonstrating package installation, 'brain-calc' game start and possible options of defeat and victory in the game.
https://asciinema.org/a/OIyO9O6AZ3G4Uj5FwTThUkB3E

#asciinema demonstating package installation, 'brain-gcd' game start and possible options of defeat and victory in the game.
https://asciinema.org/a/VBMQQanPG1fAMzW2OmAUCJRP8

#asciinema demonstating package installation, 'brain-progression' game start and possible options of defeat and victory in the game.
https://asciinema.org/a/WJH73AEAbiATAXTU2pl3kVKXO

#asciinema demonstrating package installation, 'brain-prime' game start and possible options of defeat and victory in the game. 
https://asciinema.org/a/AhfSWiMy6txsnXLI19vTXosrb