### Hexlet tests and linter status:
[![Actions Status](https://github.com/veterinastya/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/veterinastya/python-project-49/actions)

#asciinema demonstrating package installation, 'brain-even' game start and possible options of defeat and victory in the game.
https://asciinema.org/a/MkAELP3e5mxrMR1nIMRfP6CCN

#asciinema demonstrating package installation, 'brain-calc' game start and possible options of defeat and victory in the game.
https://asciinema.org/a/OIyO9O6AZ3G4Uj5FwTThUkB3E

#asciinema demonstating package installation, 'brain-gcd' game start and possible options of defeat and victory in the game.
https://asciinema.org/a/VBMQQanPG1fAMzW2OmAUCJRP8